clc;
clear;

% Load the images
image_data = load('images.mat');
images = image_data.images;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Question 1 – Face recognition
disp("Question 1 – Face recognition")
disp("*******************************a)*******************************")

% Initialize a cell array to store the vectors
vectors = cell(1, 8);

% Convert each 70x50 matrix to a 3500x1 vector and convert to double
for i = 1:8
    vectors{i} = double(reshape(images{i}, 3500, 1));
end

% Print the first 5 components of each (transposed) vector
for i = 1:8
    fprintf('First 5 components of vector %d:\n', i);
    disp(vectors{i}(1:5)');
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% b) Determine mean vector and covariance matrix
disp("*******************************b)*******************************")

% Combine the 8 training vectors into a 3500x8 matrix
training_matrix = [vectors{:}]; 

% Calculate the mean vector (3500x1)
mean_vector = mean(training_matrix, 2); % Mean across columns, results in a 3500x1 vector

% Calculate the covariance matrix (3500x3500) of the transposed
% training_matrix (column=variable, row=sample)
cov_matrix = cov(training_matrix');

% Compute the eigenvalues and eigenvectors of the covariance matrix
[eig_vectors, eig_values] = eig(cov_matrix);

% Sort eigenvalues in descending order and get indices
[eig_values, sorted_indices] = sort(diag(eig_values), 'descend');

% Select the indices corresponding to the largest 7 eigenvalues
top_eig_indices = sorted_indices(1:7);

% Retrieve the eigenvectors corresponding to the top 7 eigenvalues
top_eig_vectors = eig_vectors(:, top_eig_indices);

% Display the mean vector and the top-left 5x5 components of the covariance matrix
disp('Mean vector (first 5 components):');
disp(mean_vector(1:5)');

disp('Top-left 5x5 components of the covariance matrix:');
disp(cov_matrix(1:5, 1:5)');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% c) Project training vectors onto the principal axes
disp("*******************************c)*******************************")
% Normalize training vectors by subtracting mean vector
normalized_vectors = training_matrix - repmat(mean_vector, 1, 8);

% Project normalized vectors onto the principal axes
projected_vectors = top_eig_vectors.' * normalized_vectors;

% Display all components of each (transposed) projected vector
fprintf('Projected vectors:\n');
for i = 1:8
    fprintf('Projected vector %d:\n', i);
    fprintf('%f ', projected_vectors(:, i).'); % Display all components of 
    % each projected vector
    fprintf('\n\n');
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% d) Compute DG and KS models
disp("*******************************d)*******************************")
% Separate projected vectors into two groups (Person 1 and Person 2)
DG_vectors = projected_vectors(:, 1:4);
KS_vectors = projected_vectors(:, 5:8);

% Compute mean vector for Person 1 and Person 2
mean_vector_DG = mean(DG_vectors, 2);
mean_vector_KS = mean(KS_vectors, 2);

% Compute covariance matrix for Person 1 and Person 2
cov_matrix_DG = cov(DG_vectors');
cov_matrix_KS = cov(KS_vectors');

% Extract diagonal of covariance matrices
diag_cov_matrix_DG = diag(cov_matrix_DG);
diag_cov_matrix_KS = diag(cov_matrix_KS);

% Display all components of mean vectors and diagonals of covariance matrices
fprintf('Person 1 - Mean vector (transposed):\n');
fprintf('%f ', mean_vector_DG');
fprintf('\n');

fprintf('Person 1 - Diagonal of covariance matrix:\n');
fprintf('%f ', diag_cov_matrix_DG);
fprintf('\n\n');

fprintf('Person 2 - Mean vector (transposed):\n');
fprintf('%f ', mean_vector_KS');
fprintf('\n');

fprintf('Person 2 - Diagonal of covariance matrix:\n');
fprintf('%f ', diag_cov_matrix_KS);
fprintf('\n\n');
% e) Load and normalize the test vector
disp("*******************************e)*******************************")

% Load the test image
test_image = image_data.images{9};
test_vector = double(reshape(test_image, 3500, 1));

% Print the first 5 components of the (transposed) vector
fprintf('First 5 components of the test vector:\n');
fprintf('%f ', test_vector(1:5)');
fprintf('\n\n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% f) Project the normalized test vector onto the principal axes
disp("*******************************f)*******************************")

% Normalize the test vector
normalized_test_vector = test_vector - mean_vector;

% Project normalized test vector onto the principal axes
projected_test_vector = top_eig_vectors' * normalized_test_vector;

% Display all components of the (transposed) projected vector
fprintf('Projected test vector:\n');
fprintf('%f ', projected_test_vector');
fprintf('\n\n');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% g) Compute log likelihoods and likelihood ratios
disp("*******************************g)*******************************")

% Compute log likelihoods
log_likelihood_DG = log(mvnpdf(projected_test_vector, mean_vector_DG, diag_cov_matrix_DG'));
log_likelihood_KS = log(mvnpdf(projected_test_vector, mean_vector_KS, diag_cov_matrix_KS'));

% Compute log likelihood ratio
log_likelihood_ratio = log_likelihood_DG - log_likelihood_KS;

% Compute likelihood ratio
likelihood_ratio = exp(log_likelihood_ratio);

% Display results
fprintf('Log likelihood for DG model: %.4f\n', log_likelihood_DG);
fprintf('Log likelihood for KS model: %.4f\n', log_likelihood_KS);
fprintf('Log likelihood ratio (LLR): %.4f\n', log_likelihood_ratio);
fprintf('Likelihood ratio (LR): %.4f\n', likelihood_ratio);
fprintf('\n');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if log_likelihood_DG > log_likelihood_KS
    disp('Test image likely belongs to Person DG.');
else
    disp('Test image likely belongs to Person KS.');
end